<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        api: __DIR__.'/../routes/api.php',
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        //
        $middleware->validateCsrfTokens(except: [
        'api/payment/callback',
    ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
        // 'api/payment/callback' => \App\Http\Controllers\Api\PaymentController::class.'@callback',

    })->create();
